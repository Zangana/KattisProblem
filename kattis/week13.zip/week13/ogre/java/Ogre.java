import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.math.*;

import static java.util.stream.Collectors.*;
import static java.util.stream.IntStream.*;
import static java.util.function.Function.*;

public class Ogre
{
    public static void main(String args[])
    {
        Scanner in = new Scanner(System.in);
    }
}
